## Goals
- Practice
  - coding in C++.
  - writing unit tests to verify your work.
  - writing makefile.
  - debug memory leak.

## Getting Code
- Please fork the repository: 2024-summer-342-quiz-hello-world
- Make the code changes in your forked repo (see the TODOs in the code for details).
- This work is to be done on your Linux machine.

## Submission

Submit the link to your repo that contains the code. No need to create a PR.

## Grading

Effort-only. You will get full points with any effort made to finish the tasks.

## Team Work

Please build a team to work on this together. Each team can contain 2-4 students from this class.
